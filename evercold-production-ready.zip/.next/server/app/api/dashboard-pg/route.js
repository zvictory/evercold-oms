var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/dashboard-pg/route.js")
R.c("server/chunks/[root-of-the-server]__c0aa2235._.js")
R.c("server/chunks/[root-of-the-server]__b2da729a._.js")
R.c("server/chunks/_next-internal_server_app_api_dashboard-pg_route_actions_867a6db8.js")
R.m(82464)
module.exports=R.m(82464).exports
