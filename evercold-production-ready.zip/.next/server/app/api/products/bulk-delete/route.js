var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/products/bulk-delete/route.js")
R.c("server/chunks/[root-of-the-server]__0bd7887e._.js")
R.c("server/chunks/node_modules_zod_v4_classic_external_fa90cebf.js")
R.c("server/chunks/[root-of-the-server]__b2da729a._.js")
R.c("server/chunks/_next-internal_server_app_api_products_bulk-delete_route_actions_1034a0a1.js")
R.m(66781)
module.exports=R.m(66781).exports
