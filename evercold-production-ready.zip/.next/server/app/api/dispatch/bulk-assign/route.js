var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/dispatch/bulk-assign/route.js")
R.c("server/chunks/[root-of-the-server]__e3348091._.js")
R.c("server/chunks/[root-of-the-server]__b2da729a._.js")
R.c("server/chunks/node_modules_bcryptjs_index_42ebb250.js")
R.c("server/chunks/_next-internal_server_app_api_dispatch_bulk-assign_route_actions_b8581457.js")
R.m(76068)
module.exports=R.m(76068).exports
