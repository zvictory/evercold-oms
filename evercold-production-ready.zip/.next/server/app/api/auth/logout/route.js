var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/auth/logout/route.js")
R.c("server/chunks/[root-of-the-server]__d8794d1e._.js")
R.c("server/chunks/[root-of-the-server]__b2da729a._.js")
R.c("server/chunks/_next-internal_server_app_api_auth_logout_route_actions_5aa6c6ca.js")
R.m(83932)
module.exports=R.m(83932).exports
