var R=require("../../../../../chunks/[turbopack]_runtime.js")("server/app/api/edo/sync/download/route.js")
R.c("server/chunks/[root-of-the-server]__b8cd9f0b._.js")
R.c("server/chunks/[root-of-the-server]__a6100876._.js")
R.c("server/chunks/[root-of-the-server]__b2da729a._.js")
R.c("server/chunks/node_modules_1c3ab253._.js")
R.c("server/chunks/_next-internal_server_app_api_edo_sync_download_route_actions_b5bd82de.js")
R.m(9002)
module.exports=R.m(9002).exports
