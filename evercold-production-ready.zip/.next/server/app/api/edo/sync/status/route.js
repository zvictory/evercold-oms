var R=require("../../../../../chunks/[turbopack]_runtime.js")("server/app/api/edo/sync/status/route.js")
R.c("server/chunks/[root-of-the-server]__61980422._.js")
R.c("server/chunks/[root-of-the-server]__b2da729a._.js")
R.c("server/chunks/_next-internal_server_app_api_edo_sync_status_route_actions_c5a277a1.js")
R.m(13969)
module.exports=R.m(13969).exports
