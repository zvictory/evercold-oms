var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/assignments/route.js")
R.c("server/chunks/[root-of-the-server]__011cee65._.js")
R.c("server/chunks/[root-of-the-server]__b2da729a._.js")
R.c("server/chunks/node_modules_bcryptjs_index_42ebb250.js")
R.c("server/chunks/_next-internal_server_app_api_assignments_route_actions_f96be58b.js")
R.m(5066)
module.exports=R.m(5066).exports
