var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/driver/deliveries/route.js")
R.c("server/chunks/[root-of-the-server]__7c2a7a81._.js")
R.c("server/chunks/[root-of-the-server]__b2da729a._.js")
R.c("server/chunks/node_modules_bcryptjs_index_42ebb250.js")
R.c("server/chunks/_next-internal_server_app_api_driver_deliveries_route_actions_d2332a98.js")
R.m(28222)
module.exports=R.m(28222).exports
