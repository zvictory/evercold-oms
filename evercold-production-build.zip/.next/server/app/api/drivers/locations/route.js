var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/drivers/locations/route.js")
R.c("server/chunks/[root-of-the-server]__0b832b2f._.js")
R.c("server/chunks/[root-of-the-server]__b2da729a._.js")
R.c("server/chunks/node_modules_bcryptjs_index_42ebb250.js")
R.c("server/chunks/_next-internal_server_app_api_drivers_locations_route_actions_a5aeef0f.js")
R.m(53355)
module.exports=R.m(53355).exports
