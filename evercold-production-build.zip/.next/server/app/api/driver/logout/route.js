var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/driver/logout/route.js")
R.c("server/chunks/[root-of-the-server]__cd067593._.js")
R.c("server/chunks/[root-of-the-server]__b2da729a._.js")
R.c("server/chunks/node_modules_bcryptjs_index_42ebb250.js")
R.c("server/chunks/_next-internal_server_app_api_driver_logout_route_actions_7e908f3b.js")
R.m(75618)
module.exports=R.m(75618).exports
