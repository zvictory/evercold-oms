var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/customers/[id]/route.js")
R.c("server/chunks/[root-of-the-server]__7490f4e4._.js")
R.c("server/chunks/[root-of-the-server]__b2da729a._.js")
R.c("server/chunks/_next-internal_server_app_api_customers_[id]_route_actions_15aafb3f.js")
R.m(58296)
module.exports=R.m(58296).exports
