var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/auth/change-password/route.js")
R.c("server/chunks/[root-of-the-server]__42da23a6._.js")
R.c("server/chunks/[root-of-the-server]__b2da729a._.js")
R.c("server/chunks/node_modules_bcryptjs_index_42ebb250.js")
R.c("server/chunks/_next-internal_server_app_api_auth_change-password_route_actions_2c23f77f.js")
R.m(56219)
module.exports=R.m(56219).exports
