var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/edo/test-connection/route.js")
R.c("server/chunks/[root-of-the-server]__6e8b17d3._.js")
R.c("server/chunks/[root-of-the-server]__a6100876._.js")
R.c("server/chunks/[root-of-the-server]__b2da729a._.js")
R.c("server/chunks/node_modules_1c3ab253._.js")
R.c("server/chunks/_next-internal_server_app_api_edo_test-connection_route_actions_eff11413.js")
R.m(34480)
module.exports=R.m(34480).exports
