#!/bin/bash
# Auto-Customer Creation - Quick Deploy Script
# Run from: /var/www/vhosts/evercold.uz/app.evercold.uz

echo "═══════════════════════════════════════════════════════════"
echo "  Auto-Customer Creation Deployment"
echo "═══════════════════════════════════════════════════════════"
echo ""

# Check we're in the right directory
if [ ! -f "package.json" ]; then
    echo "❌ Error: Not in app directory!"
    echo "   Please run from: /var/www/vhosts/evercold.uz/app.evercold.uz"
    exit 1
fi

# Backup current file
echo "📦 Creating backup..."
if [ -f "src/app/api/upload/route.ts" ]; then
    cp src/app/api/upload/route.ts src/app/api/upload/route.ts.backup-$(date +%Y%m%d-%H%M%S)
    echo "✅ Backup created"
else
    echo "⚠️  Original file not found (fresh install?)"
fi

# Copy new file
echo ""
echo "📝 Installing new upload route..."
cp src/app/api/upload/route.ts.new src/app/api/upload/route.ts
echo "✅ File updated"

# Build
echo ""
echo "🔨 Building application..."
npm run build

if [ $? -eq 0 ]; then
    echo ""
    echo "═══════════════════════════════════════════════════════════"
    echo "  ✅ DEPLOYMENT SUCCESSFUL!"
    echo "═══════════════════════════════════════════════════════════"
    echo ""
    echo "Next steps:"
    echo "1. Restart your Node.js app in Plesk panel"
    echo "2. Test by uploading an Excel file with a new customer"
    echo "3. Check logs for: 🆕 Auto-created customer: [Name]"
    echo ""
else
    echo ""
    echo "═══════════════════════════════════════════════════════════"
    echo "  ❌ BUILD FAILED!"
    echo "═══════════════════════════════════════════════════════════"
    echo ""
    echo "Restoring backup..."
    if [ -f "src/app/api/upload/route.ts.backup-$(date +%Y%m%d)"* ]; then
        cp src/app/api/upload/route.ts.backup-$(date +%Y%m%d)* src/app/api/upload/route.ts
        echo "✅ Backup restored"
    fi
    echo ""
    echo "Please check error messages above and contact support."
    exit 1
fi
