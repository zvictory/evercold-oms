var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/drivers/route.js")
R.c("server/chunks/[root-of-the-server]__58388d9b._.js")
R.c("server/chunks/[root-of-the-server]__db2b3a24._.js")
R.c("server/chunks/node_modules_bcryptjs_index_42ebb250.js")
R.c("server/chunks/_next-internal_server_app_api_drivers_route_actions_9656ed85.js")
R.m(92906)
module.exports=R.m(92906).exports
