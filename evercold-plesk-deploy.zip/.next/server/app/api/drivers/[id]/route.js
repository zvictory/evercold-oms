var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/drivers/[id]/route.js")
R.c("server/chunks/[root-of-the-server]__414d86ee._.js")
R.c("server/chunks/[root-of-the-server]__db2b3a24._.js")
R.c("server/chunks/node_modules_bcryptjs_index_42ebb250.js")
R.c("server/chunks/_next-internal_server_app_api_drivers_[id]_route_actions_b71c8a15.js")
R.m(30604)
module.exports=R.m(30604).exports
