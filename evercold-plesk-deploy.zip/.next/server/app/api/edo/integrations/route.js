var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/edo/integrations/route.js")
R.c("server/chunks/[root-of-the-server]__ecd3a6d5._.js")
R.c("server/chunks/[root-of-the-server]__db2b3a24._.js")
R.c("server/chunks/_next-internal_server_app_api_edo_integrations_route_actions_9256d357.js")
R.m(40073)
module.exports=R.m(40073).exports
