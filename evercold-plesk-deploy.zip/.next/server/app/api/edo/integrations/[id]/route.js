var R=require("../../../../../chunks/[turbopack]_runtime.js")("server/app/api/edo/integrations/[id]/route.js")
R.c("server/chunks/[root-of-the-server]__c444b9ab._.js")
R.c("server/chunks/[root-of-the-server]__db2b3a24._.js")
R.c("server/chunks/_next-internal_server_app_api_edo_integrations_[id]_route_actions_7ca315c1.js")
R.m(18670)
module.exports=R.m(18670).exports
