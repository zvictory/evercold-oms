var R=require("../../../../../chunks/[turbopack]_runtime.js")("server/app/api/edo/sync/upload/route.js")
R.c("server/chunks/[root-of-the-server]__e4875ff2._.js")
R.c("server/chunks/[root-of-the-server]__a6100876._.js")
R.c("server/chunks/[root-of-the-server]__db2b3a24._.js")
R.c("server/chunks/node_modules_1c3ab253._.js")
R.c("server/chunks/_next-internal_server_app_api_edo_sync_upload_route_actions_1379690f.js")
R.m(62152)
module.exports=R.m(62152).exports
