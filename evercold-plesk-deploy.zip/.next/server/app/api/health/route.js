var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/health/route.js")
R.c("server/chunks/[root-of-the-server]__407433ef._.js")
R.c("server/chunks/[root-of-the-server]__db2b3a24._.js")
R.c("server/chunks/_next-internal_server_app_api_health_route_actions_da3433c4.js")
R.m(43007)
module.exports=R.m(43007).exports
