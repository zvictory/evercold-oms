var R=require("../../../../../../chunks/[turbopack]_runtime.js")("server/app/api/driver/deliveries/[deliveryId]/arrive/route.js")
R.c("server/chunks/[root-of-the-server]__949de0a5._.js")
R.c("server/chunks/[root-of-the-server]__db2b3a24._.js")
R.c("server/chunks/node_modules_bcryptjs_index_42ebb250.js")
R.c("server/chunks/ce889_server_app_api_driver_deliveries_[deliveryId]_arrive_route_actions_fa8f8c12.js")
R.m(97534)
module.exports=R.m(97534).exports
