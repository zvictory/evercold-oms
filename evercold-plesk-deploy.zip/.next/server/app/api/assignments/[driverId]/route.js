var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/assignments/[driverId]/route.js")
R.c("server/chunks/[root-of-the-server]__e1b0c285._.js")
R.c("server/chunks/[root-of-the-server]__db2b3a24._.js")
R.c("server/chunks/_next-internal_server_app_api_assignments_[driverId]_route_actions_d69a328d.js")
R.m(62811)
module.exports=R.m(62811).exports
