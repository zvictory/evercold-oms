var R=require("../../../../../chunks/[turbopack]_runtime.js")("server/app/api/customers/[id]/branches/route.js")
R.c("server/chunks/[root-of-the-server]__df2a9791._.js")
R.c("server/chunks/[root-of-the-server]__db2b3a24._.js")
R.c("server/chunks/_next-internal_server_app_api_customers_[id]_branches_route_actions_2be581f4.js")
R.m(24971)
module.exports=R.m(24971).exports
