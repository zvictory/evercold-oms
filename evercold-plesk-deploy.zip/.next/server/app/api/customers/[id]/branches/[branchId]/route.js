var R=require("../../../../../../chunks/[turbopack]_runtime.js")("server/app/api/customers/[id]/branches/[branchId]/route.js")
R.c("server/chunks/[root-of-the-server]__d9225bff._.js")
R.c("server/chunks/[root-of-the-server]__db2b3a24._.js")
R.c("server/chunks/ce889_server_app_api_customers_[id]_branches_[branchId]_route_actions_43ae2c69.js")
R.m(22209)
module.exports=R.m(22209).exports
