var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/customers/route.js")
R.c("server/chunks/[root-of-the-server]__06b973a7._.js")
R.c("server/chunks/[root-of-the-server]__db2b3a24._.js")
R.c("server/chunks/node_modules_bcryptjs_index_42ebb250.js")
R.c("server/chunks/_next-internal_server_app_api_customers_route_actions_1c336a10.js")
R.m(55836)
module.exports=R.m(55836).exports
